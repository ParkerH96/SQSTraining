<div class="welcome">
	<h1>Welcome to the SQS Training Website!</h1>
	<p>This website is for testing automated script to find different errors throughout the site. Log in or sign up to begin!</p><br><br>
	<button class="btn" onclick="location.href='user_login.php'">Sign In</button>
	<button class="btn" onclick="location.href='user_register.php'">Sign Up</button>
</div>
