<?php
/**
The working version simply refrains from breaking the error messages.
*/
//$_SESSION['SMSReport'] = "sms report";
//$_SESSION['SMSReport'] = $smsReport;
//$_SESSION['SubscriptionReport'] = $subscriptionReport;
echo '<meta http-equiv="refresh" content="0; ../index.php" />';
?>
