<!--
  Last Modified: Spring 2018
  Function: Displays name on Profile Page
  Change Log: Restructed to conform with new profile page
  Error: Doesn't populate data into input field
-->

<input id="FirstName" type="text" name="first_name" maxlength="25" value="" disabled><br><br>
<input id="LastName" type="text" name="last_name" maxlength="25" value="" disabled><br><br>
