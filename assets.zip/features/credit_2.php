<!--
  Last Modified: Spring 2018
  Function: Display Footer at bottom of the page
  Change Log: Restructed to show at bottom of content and not stick to bottom of the screen
  Error: Displays no content in footer
-->

<footer class="footer">
  <p>&nbsp;</p>
</footer>

<style>
.footer {
    z-index: 1000;
    position: fixed;
    height: 40px;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #343A40;
    color: white;
    text-align: center;
}
</style>
