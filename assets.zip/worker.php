<script type="text/javascript">
  console.log("In file");
</script>

<?php

  while (True) {
    ?>
    <script type="text/javascript">
      postMessage("10 seconds");
      console.log("10 Seconds");
    </script>
    <?php
    sleep(10);
  }
?>
